import pandas as pd
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans, AgglomerativeClustering
from sklearn.metrics import silhouette_score
from sklearn.preprocessing import StandardScaler
import numpy as np

# Load the Excel file
file_path = 'classification_results.xlsx'  # Replace with your file path
df = pd.read_excel(file_path)

# Filter the dataframe for correctly and misclassified images
correct_df = df[df['Correct Prediction'] == 'Yes']
misclassified_df = df[df['Correct Prediction'] == 'No']

# Extract the luminance values of misclassified images
luminance_values = misclassified_df['Luminescence'].values.reshape(-1, 1)

# Normalize the luminance values
scaler = StandardScaler()
luminance_values_scaled = scaler.fit_transform(luminance_values)

# Determine the optimal number of clusters using the Elbow Method and Silhouette Score
def find_optimal_clusters(X, max_clusters=10):
    inertia = []
    silhouette_scores = []
    num_clusters_range = range(2, max_clusters + 1)
    
    for n_clusters in num_clusters_range:
        kmeans = KMeans(n_clusters=n_clusters, random_state=42)
        kmeans.fit(X)
        inertia.append(kmeans.inertia_)
        labels = kmeans.labels_
        silhouette_avg = silhouette_score(X, labels)
        silhouette_scores.append(silhouette_avg)
    
    # Plot Elbow Method
    plt.figure(figsize=(12, 6))
    plt.subplot(1, 2, 1)
    plt.plot(num_clusters_range, inertia, marker='o', linestyle='--')
    plt.xlabel('Number of Clusters')
    plt.ylabel('Inertia')
    plt.title('Elbow Method')

    # Plot Silhouette Scores
    plt.subplot(1, 2, 2)
    plt.plot(num_clusters_range, silhouette_scores, marker='o', linestyle='--')
    plt.xlabel('Number of Clusters')
    plt.ylabel('Silhouette Score')
    plt.title('Silhouette Score')
    
    plt.tight_layout()
    plt.show()

    # Determine optimal clusters
    optimal_clusters_elbow = max(np.argmin(np.diff(inertia, 2)), 2)
    optimal_clusters_silhouette = max(np.argmax(silhouette_scores) , 2)

    return optimal_clusters_elbow, optimal_clusters_silhouette


optimal_clusters_elbow, optimal_clusters_silhouette = find_optimal_clusters(luminance_values_scaled)

print("optimal_clusters_elbow: ", optimal_clusters_elbow, "optimal_clusters_silhouette: ", optimal_clusters_silhouette)


# Apply Agglomerative Clustering with the optimal number of clusters
optimal_clusters = max(optimal_clusters_elbow, optimal_clusters_silhouette)
agglomerative_clust = AgglomerativeClustering(n_clusters=optimal_clusters)
labels = agglomerative_clust.fit_predict(luminance_values_scaled)

# Add cluster labels to the dataframe
misclassified_df['Cluster'] = labels

# Initialize lists to store cluster details
cluster_details = []

# Calculate details for each cluster
for cluster in range(optimal_clusters):
    cluster_points = misclassified_df[misclassified_df['Cluster'] == cluster]
    cluster_size = len(cluster_points)
    min_luminance = cluster_points['Luminescence'].min()
    max_luminance = cluster_points['Luminescence'].max()

    # Calculate correctly classified examples in the luminance range
    correct_in_range = correct_df[
        (correct_df['Luminescence'] >= min_luminance) &
        (correct_df['Luminescence'] <= max_luminance)
    ]
    correct_count = len(correct_in_range)

    # Calculate the misclassification rate
    misclassification_rate = cluster_size / (cluster_size + correct_count)
    
    # Store cluster details
    cluster_details.append({
        'Cluster': cluster + 1,
        'Incorrect Count': cluster_size,
        'Correct Count': correct_count,
        'Misclassification Rate': misclassification_rate,
        'Luminance Range': (min_luminance, max_luminance)
    })

# Print the details for each cluster
for detail in cluster_details:
    print(f"Cluster {detail['Cluster']}:")
    print(f"  Incorrect Count: {detail['Incorrect Count']}")
    print(f"  Correct Count: {detail['Correct Count']}")
    print(f"  Misclassification Rate: {detail['Misclassification Rate']:.2f}")
    print(f"  Luminance Range: {detail['Luminance Range'][0]:.2f} - {detail['Luminance Range'][1]:.2f}")
    print("-" * 50)

# Create a combined plot
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(14, 12))

# Plot 1: Luminance vs. Classification Results with Agglomerative Clustering
ax1.hist(misclassified_df['Luminescence'], bins=30, color='blue', edgecolor='black', alpha=0.3, label='Misclassified Frequency')
ax1.scatter(correct_df['Luminescence'], [0]*len(correct_df), color='green', marker='o', label='Correctly Classified')
ax1.scatter(misclassified_df['Luminescence'], [0]*len(misclassified_df), color='red', marker='x', label='Misclassified')

# Scatter plot for the clustered misclassified points using Agglomerative Clustering
for cluster in range(optimal_clusters):
    cluster_points = misclassified_df[misclassified_df['Cluster'] == cluster]
    ax1.scatter(cluster_points['Luminescence'], [-cluster-1]*len(cluster_points), 
                label=f'Cluster {cluster+1}', marker='x', cmap='viridis')

ax1.set_title('Luminance vs. Classification Results with Agglomerative Clustering')
ax1.set_xlabel('Luminance')
ax1.set_ylabel('Frequency of Misclassified Images')
ax1.legend(loc='center left', bbox_to_anchor=(1, 0.5))
ax1.grid(True)

# Plot 2: Cluster Analysis: Misclassification Rate and Counts
bar_width = 0.35
index = np.arange(len(cluster_details))

ax2.bar(index, [detail['Incorrect Count'] for detail in cluster_details], bar_width, label='Misclassified')
ax2.bar(index + bar_width, [detail['Correct Count'] for detail in cluster_details], bar_width, label='Correctly Classified')

# Add the misclassification rate as text on the bars
for i, detail in enumerate(cluster_details):
    ax2.text(index[i], detail['Incorrect Count'] + 0.5, f'{detail["Misclassification Rate"]:.2f}', 
             ha='center', va='bottom', fontsize=10, color='red')
    ax2.text(index[i] + bar_width, detail['Correct Count'] + 0.5, f'{detail["Correct Count"]}', 
             ha='center', va='bottom', fontsize=10)

ax2.set_xlabel('Cluster')
ax2.set_ylabel('Count')
ax2.set_title('Cluster Analysis: Misclassification Rate and Counts')
ax2.set_xticks(index + bar_width / 2)
ax2.set_xticklabels([f'Cluster {detail["Cluster"]}' for detail in cluster_details])
ax2.legend()
ax2.grid(True)

# Show the combined plot
plt.tight_layout()
plt.show()

# Identify the weak point ranges
weak_point_ranges = []
for detail in cluster_details:
    if detail['Misclassification Rate'] > 0.5:  # Example threshold for considering a weak point
        weak_point_ranges.append(detail['Luminance Range'])

print("\nOptimal Weak Point Ranges for Luminance Values:")
for weak_range in weak_point_ranges:
    print(f"Luminance Range: {weak_range[0]:.2f} - {weak_range[1]:.2f}")
