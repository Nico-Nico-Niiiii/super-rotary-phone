import pandas as pd
import matplotlib.pyplot as plt
from sklearn.cluster import MeanShift, estimate_bandwidth
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import silhouette_score, make_scorer
import numpy as np
from scipy.spatial.distance import pdist

# Load the Excel file
file_path = 'classification_results.xlsx'  # Replace with your file path
df = pd.read_excel(file_path)

# Filter the dataframe for correctly and misclassified images
correct_df = df[df['Correct Prediction'] == 'Yes']
misclassified_df = df[df['Correct Prediction'] == 'No']

# Extract the luminance values of misclassified images
luminance_values = misclassified_df['Luminescence'].values.reshape(-1, 1)

# Normalize the luminance values
luminance_values_scaled = luminance_values  # scaler.fit_transform(luminance_values)

# Method 1: Bandwidth using estimate_bandwidth (with quantile)
bandwidth_quantile = estimate_bandwidth(luminance_values_scaled, quantile=0.2)

# Method 2: Bandwidth using median distance between points
pairwise_distances = pdist(luminance_values_scaled)
bandwidth_median = np.median(pairwise_distances)

# Method 3: Bandwidth using cross-validation (GridSearchCV with silhouette score)
def custom_silhouette_score(estimator, X):
    labels = estimator.fit_predict(X)
    if len(np.unique(labels)) > 1:
        return silhouette_score(X, labels)
    else:
        return -1  # Poor score for single cluster

param_grid = {'bandwidth': np.linspace(bandwidth_median / 2, bandwidth_median * 2, 10)}
grid_search = GridSearchCV(MeanShift(bin_seeding=True), param_grid, cv=5, scoring=make_scorer(custom_silhouette_score))
grid_search.fit(luminance_values_scaled)
bandwidth_cv = grid_search.best_params_['bandwidth']

# Generate separate plots for each bandwidth method
fig, axs = plt.subplots(3, 1, figsize=(10, 18))

# Plot for Method 1: Bandwidth using estimate_bandwidth (with quantile)
axs[0].axvline(x=bandwidth_quantile, label=f'Quantile Method: {bandwidth_quantile:.3f}', color='r', linestyle='--')
axs[0].hist(pairwise_distances, bins=30, color='blue', edgecolor='black', alpha=0.3)
axs[0].set_xlabel('Pairwise Distances')
axs[0].set_ylabel('Frequency')
axs[0].set_title('Quantile Method Bandwidth Estimation')
axs[0].legend()
axs[0].grid(True)

# Plot for Method 2: Bandwidth using median distance between points
axs[1].axvline(x=bandwidth_median, label=f'Median Distance: {bandwidth_median:.3f}', color='g', linestyle='--')
axs[1].hist(pairwise_distances, bins=30, color='blue', edgecolor='black', alpha=0.3)
axs[1].set_xlabel('Pairwise Distances')
axs[1].set_ylabel('Frequency')
axs[1].set_title('Median Distance Method Bandwidth Estimation')
axs[1].legend()
axs[1].grid(True)

# Plot for Method 3: Bandwidth using cross-validation (GridSearchCV)
axs[2].axvline(x=bandwidth_cv, label=f'Cross-Validation: {bandwidth_cv:.3f}', color='b', linestyle='--')
axs[2].hist(pairwise_distances, bins=30, color='blue', edgecolor='black', alpha=0.3)
axs[2].set_xlabel('Pairwise Distances')
axs[2].set_ylabel('Frequency')
axs[2].set_title('Cross-Validation Method Bandwidth Estimation')
axs[2].legend()
axs[2].grid(True)

# Adjust layout and show the combined plot for bandwidth estimation
plt.tight_layout()
plt.show()

# Apply Mean Shift clustering with different bandwidths and visualize the results
for bandwidth, label in zip([bandwidth_quantile, bandwidth_median, bandwidth_cv], 
                            ['Quantile Method', 'Median Distance', 'Cross-Validation']):
    mean_shift = MeanShift(bandwidth=bandwidth, bin_seeding=True)
    labels = mean_shift.fit_predict(luminance_values_scaled)

    # Add cluster labels to the dataframe
    misclassified_df['Cluster'] = labels

    # Determine the number of clusters
    unique_labels = np.unique(labels)
    num_clusters = len(unique_labels)

    # Initialize lists to store cluster details
    cluster_details = []

    # Calculate details for each cluster
    for cluster in unique_labels:
        cluster_points = misclassified_df[misclassified_df['Cluster'] == cluster]
        cluster_size = len(cluster_points)
        min_luminance = cluster_points['Luminescence'].min()
        max_luminance = cluster_points['Luminescence'].max()

        # Calculate correctly classified examples in the luminance range
        correct_in_range = correct_df[
            (correct_df['Luminescence'] >= min_luminance) &
            (correct_df['Luminescence'] <= max_luminance)
        ]
        correct_count = len(correct_in_range)

        # Calculate the misclassification rate
        misclassification_rate = cluster_size / (cluster_size + correct_count)

        # Store cluster details
        cluster_details.append({
            'Cluster': cluster + 1,
            'Incorrect Count': cluster_size,
            'Correct Count': correct_count,
            'Misclassification Rate': misclassification_rate,
            'Luminance Range': (min_luminance, max_luminance)
        })

    # Create a combined plot for each bandwidth method
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(14, 12))

    # Plot 1: Luminance vs. Classification Results with Mean Shift Clustering
    ax1.hist(misclassified_df['Luminescence'], bins=30, color='blue', edgecolor='black', alpha=0.3, label='Misclassified Frequency')
    ax1.scatter(correct_df['Luminescence'], [0]*len(correct_df), color='green', marker='o', label='Correctly Classified')
    ax1.scatter(misclassified_df['Luminescence'], [0]*len(misclassified_df), color='red', marker='x', label='Misclassified')

    # Scatter plot for the clustered misclassified points using Mean Shift
    for cluster in unique_labels:
        cluster_points = misclassified_df[misclassified_df['Cluster'] == cluster]
        ax1.scatter(cluster_points['Luminescence'], [-cluster-1]*len(cluster_points), 
                    label=f'Cluster {cluster+1}', marker='x', cmap='viridis')

    ax1.set_title(f'Luminance vs. Classification Results with Mean Shift Clustering ({label})')
    ax1.set_xlabel('Luminance')
    ax1.set_ylabel('Frequency of Misclassified Images')
    ax1.legend(loc='center left', bbox_to_anchor=(1, 0.5))
    ax1.grid(True)

    # Plot 2: Cluster Analysis: Misclassification Rate and Counts
    bar_width = 0.35
    index = np.arange(len(cluster_details))

    ax2.bar(index, [detail['Incorrect Count'] for detail in cluster_details], bar_width, label='Misclassified')
    ax2.bar(index + bar_width, [detail['Correct Count'] for detail in cluster_details], bar_width, label='Correctly Classified')

    # Add the misclassification rate as text on the bars
    for i, detail in enumerate(cluster_details):
        ax2.text(index[i], detail['Incorrect Count'] + 0.5, f'{detail["Misclassification Rate"]:.2f}', 
                 ha='center', va='bottom', fontsize=10, color='red')
        ax2.text(index[i] + bar_width, detail['Correct Count'] + 0.5, f'{detail["Correct Count"]}', 
                 ha='center', va='bottom', fontsize=10)

    ax2.set_xlabel('Cluster')
    ax2.set_ylabel('Count')
    ax2.set_title('Cluster Analysis: Misclassification Rate and Counts')
    ax2.set_xticks(index + bar_width / 2)
    ax2.set_xticklabels([f'Cluster {detail["Cluster"]}' for detail in cluster_details])
    ax2.legend()
    ax2.grid(True)

    # Show the combined plot
    plt.tight_layout()
    plt.show()

# Identify the weak point ranges
weak_point_ranges = []
for detail in cluster_details:
    if detail['Misclassification Rate'] > 0.5:  # Example threshold for considering a weak point
        weak_point_ranges.append(detail['Luminance Range'])

print("\nOptimal Weak Point Ranges for Luminance Values:")
for weak_range in weak_point_ranges:
    print(f"Luminance Range: {weak_range[0]:.2f} - {weak_range[1]:.2f}")
